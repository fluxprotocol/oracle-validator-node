import DataRequest from "../../../models/DataRequest";
import { NearResolutionWindowGraphData } from "./NearResolutionWindow";
import NearProviderOptions from '../NearProviderOptions';
import NearProvider from "../NearProvider";
import { Outcome, transformToOutcome } from "../../../models/DataRequestOutcome";
import { nsToMs } from "../../../utils/dateUtils";
import { parseJson } from "../../../utils/jsonUtils";
import { transformNearOutcomeToOutcome } from "../NearService";

export interface NearDataRequestGraphData {
    id: string;
    block_height: string;
    settlement_time: string;
    date: string;
    final_arbitrator_triggered: boolean;
    global_config_id: string;
    initial_challenge_period: string;
    outcomes: string[];
    requestor: string;
    target_contract: string;
    finalized_outcome: string | null;
    config: {
        stake_token: string;
    };
    sources: {
        end_point: string;
        source_path: string;
    }[];
    resolution_windows: NearResolutionWindowGraphData[];
    data_type: string;
}

interface NumberDataType {
    Number: string;
}

export function transformNearDataRequestToDataRequest(providerOptions: NearProviderOptions, data: NearDataRequestGraphData): DataRequest {
    // A string will return null because it's not parsable.
    const parsedDataType = parseJson<NumberDataType>(data.data_type);

    return new DataRequest({
        contractId: providerOptions.oracleContractId,
        executeResult: undefined,
        id: data.id,
        providerId: NearProvider.id,
        settlementTime: new Date(nsToMs(Number(data.settlement_time))),
        outcomes: data.outcomes,
        sources: data.sources,
        tokenContractId: data.config.stake_token,
        staking: [],
        resolutionWindows: data.resolution_windows.map(rw => {
            return {
                bondSize: rw.bond_size,
                endTime: new Date(Number(rw.end_time) / 1000000),
                round: rw.round,
                bondedOutcome: rw.bonded_outcome ? transformNearOutcomeToOutcome(rw.bonded_outcome) : undefined,
            }
        }),
        finalArbitratorTriggered: data.final_arbitrator_triggered,
        finalizedOutcome: data.finalized_outcome ? transformToOutcome(data.finalized_outcome) : undefined,
        dataType: parsedDataType ? { type: 'number', multiplier: parsedDataType.Number } : { type: 'string' },
    });
}
